#include "memory_map.h"

 code  code_table[MAX_INSTRACTION_LENGTH];
 data  data_table[MAX_DATA_LENGTH];
 symbol * head_symbol;
/*Index*/
 int IC;
 int DC;
/*symbol data_table[MAX_DATA_LENGTH];*/

