#include "definition.h"
#define MAX_INSTRACTION_LENGTH 200
#define MAX_DATA_LENGTH 200